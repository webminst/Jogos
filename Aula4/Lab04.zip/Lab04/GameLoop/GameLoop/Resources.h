
#define IDI_ICON                       101
#define IDC_CURSOR					   201
